package location.dao;

import location.models.Voiture;
import location.utils.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VoitureDAO {
    // Méthode pour ajouter une voiture
    public boolean ajouter(Voiture voiture) {
        String sql = "INSERT INTO Voiture (marque, modele, annee, immatriculation, etat, disponibilite, prix_jour, carburant, transmission) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Récupérer l'ID de voiture maximal actuel et ajouter 1
            int newId = getNextVoitureId();
            
            stmt.setInt(1, newId);
            stmt.setString(2, voiture.getMarque());
            stmt.setString(3, voiture.getModele());
            stmt.setInt(4, voiture.getAnnee());
            stmt.setString(5, voiture.getImmatriculation());
            stmt.setString(6, voiture.getEtat() != null ? voiture.getEtat() : "En marche");
            stmt.setString(7, voiture.isDisponible() ? "Disponible" : "Louée");
            stmt.setDouble(8, voiture.getPrixJour());
            stmt.setString(9, voiture.getCarburant());
            stmt.setString(10, voiture.getTransmission());
            
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout de la voiture: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Obtenir le prochain ID pour une nouvelle voiture
    private int getNextVoitureId() {
        int maxId = 0;
        String sql = "SELECT MAX(immatriculation) FROM Voiture";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                maxId = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération du prochain ID: " + e.getMessage());
        }
        
        return maxId + 1;
    }

    // Méthode pour modifier une voiture
    public boolean modifier(Voiture voiture) {
        String sql = "UPDATE Voiture SET marque = ?, modele = ?, annee = ?, immatriculation = ?, "
               + "etat = ?, disponibilite = ?, prix_jour = ?, carburant = ?, transmission = ? "
               + "WHERE immatriculation = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, voiture.getMarque());
            stmt.setString(2, voiture.getModele());
            stmt.setInt(3, voiture.getAnnee());
            stmt.setString(4, voiture.getImmatriculation());
            stmt.setString(5, voiture.getEtat());
            stmt.setString(6, voiture.isDisponible() ? "disponible" : "louee");
            stmt.setDouble(7, voiture.getPrixJour());
            stmt.setString(8, voiture.getCarburant());
            stmt.setString(9, voiture.getTransmission());
            stmt.setString(10, voiture.getImmatriculation());
            
            
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification de la voiture: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode pour supprimer une voiture
    public boolean supprimer(String immatriculation) {
        String sql = "DELETE FROM Voiture WHERE immatriculation = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, immatriculation);
            
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression de la voiture: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Méthode pour supprimer une voiture par son ID
    public boolean supprimerParId(int idVoiture) {
        String sql = "DELETE FROM Voiture WHERE immatriculation = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idVoiture);
            
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression de la voiture: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode pour trouver une voiture par son immatriculation
    public Voiture trouverParImmatriculation(String immatriculation) {
        String sql = "SELECT * FROM Voiture WHERE immatriculation = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, immatriculation);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToVoiture(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de la voiture: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    
    public List<Voiture> trouverParMarqueOuModele(String recherche) {
    List<Voiture> voitures = new ArrayList<>();
    String sql = "SELECT * FROM Voiture WHERE LOWER(marque) LIKE ? OR LOWER(modele) LIKE ?";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        String critere = "%" + recherche.toLowerCase() + "%";
        stmt.setString(1, critere);
        stmt.setString(2, critere);
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
            Voiture voiture = mapResultSetToVoiture(rs);
            voitures.add(voiture);
        }
    } catch (SQLException e) {
        System.err.println("Erreur lors de la recherche par marque ou modèle: " + e.getMessage());
        e.printStackTrace();
    }
    
    return voitures;
}


    // Méthode pour lister toutes les voitures
    public List<Voiture> listerTout() {
        List<Voiture> voitures = new ArrayList<>();
        String sql = "SELECT * FROM Voiture ORDER BY immatriculation";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                voitures.add(mapResultSetToVoiture(rs));
            }
        }catch (Exception e) {
            System.err.println("Erreur lors de l'authentification de l'utilisateur: " + e.getMessage());
            e.printStackTrace();
        }
        
        return voitures;
    }
    
    // Méthode pour trouver une voiture par son ID
    public Voiture trouverParId(String idVoiture) {
        String sql = "SELECT * FROM Voiture WHERE immatriculation = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, idVoiture);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToVoiture(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de la voiture: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    // Méthode pour lister uniquement les voitures disponibles
    public List<Voiture> listerDisponibles() {
        List<Voiture> voitures = new ArrayList<>();
        String sql = "SELECT * FROM Voiture WHERE disponibilite = 'disponible' ORDER BY immatriculation";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                voitures.add(mapResultSetToVoiture(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des voitures disponibles: " + e.getMessage());
            e.printStackTrace();
        }
        
        return voitures;
    }
    
    // Méthode utilitaire pour mapper un ResultSet vers un objet Voiture
    private Voiture mapResultSetToVoiture(ResultSet rs) throws SQLException {
        Voiture voiture = new Voiture();
        voiture.setMarque(rs.getString("marque"));
        voiture.setModele(rs.getString("modele"));
        voiture.setAnnee(rs.getInt("annee"));
        voiture.setImmatriculation(rs.getString("immatriculation"));
        voiture.setEtat(rs.getString("etat"));
        voiture.setDisponibilite(rs.getString("disponibilite"));
        voiture.setPrixJour(rs.getDouble("prix_jour"));
        voiture.setcarburant(rs.getString("carburant"));
        voiture.setTransmission(rs.getString("transmission"));
        return voiture;
    }
    
    public List<Voiture> trouverParPrixMax(double prixMax) {
    List<Voiture> voitures = new ArrayList<>();
    String sql = "SELECT * FROM Voiture WHERE prix_jour <= ?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setDouble(1, prixMax);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            voitures.add(mapResultSetToVoiture(rs));
        }

    } catch (SQLException e) {
        System.err.println("Erreur lors de la recherche par prix max: " + e.getMessage());
        e.printStackTrace();
    }

    return voitures;
}

}
