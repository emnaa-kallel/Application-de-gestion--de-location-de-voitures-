package location.models;

/**
 * Classe représentant un personnel selon le schéma Oracle.
 * CIN NUMBER(8) PRIMARY KEY,
 * role VARCHAR2(20) CHECK (role IN ('admin', 'employe')),
 * FOREIGN KEY (CIN) REFERENCES Utilisateur(CIN) ON DELETE CASCADE
 */
public class Personnel {
    private int cin;
    private String role;
    
    // Default constructor
    public Personnel() {}
    
    // Full constructor
    public Personnel(int cin, String role) {
        this.cin = cin;
        setRole(role);
    }
    
    // Getters and Setters
    public int getCin() {
        return cin;
    }
    
    public void setCin(int cin) {
        this.cin = cin;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        if (role != null && (role.equals("admin") || role.equals("employe"))) {
            this.role = role;
        } else {
            throw new IllegalArgumentException("Le rôle doit être 'admin' ou 'employe'");
        }
    }
    
    @Override
    public String toString() {
        return "Personnel{" +
                "cin=" + cin +
                ", role='" + role + '\'' +
                '}';
    }
}
