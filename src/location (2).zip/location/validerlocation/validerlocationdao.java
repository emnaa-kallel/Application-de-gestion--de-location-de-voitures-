/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package location.validerlocation;

/**
 *
 * @author emnak
 */
public class validerlocationdao {
    private String idloc;
    private String datef;
    private String imm;

    public validerlocationdao(String idloc, String datef, String imm) {
        initComponents();
        this.idloc = idloc;
        this.datef = datef;
        this.imm = imm;

        
    }

    private void initComponents() {
    }
}
